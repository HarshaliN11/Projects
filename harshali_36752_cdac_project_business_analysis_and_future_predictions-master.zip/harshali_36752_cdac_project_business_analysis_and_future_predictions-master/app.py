
from flask import Flask, request, jsonify, render_template

import model



app = Flask(__name__)



@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    int_features = [x for x in request.form.values()]
    # char_features='m'
    # final_features = [np.array(periods=int_features,freq='m')]
    prediction =model.main(int(int_features[0]),int_features[1])

    # output = prediction[0], 2
    name = ""

    return render_template('image1.html',url="{}".format(int_features[1]))


if __name__ == "__main__":
    app.run(debug=True)