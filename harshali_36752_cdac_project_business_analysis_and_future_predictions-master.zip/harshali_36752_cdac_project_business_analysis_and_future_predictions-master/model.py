def main(period,category):

    from pyspark.sql.types import StructField, DateType, StringType, DoubleType, StructType
    import matplotlib.pyplot as plt
    import pandas as pd
    import numpy as np
    from fbprophet.diagnostics import performance_metrics, cross_validation
    from matplotlib.ticker import StrMethodFormatter
    from fbprophet import Prophet
    # from pyspark.sql.types import *
    from pyspark.sql.functions import pandas_udf,PandasUDFType
    from pyspark.sql.functions import col
    from pyspark.sql import SparkSession
    from pyspark.sql.functions import current_date
    from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error,accuracy_score
    from pyspark.sql.functions import desc
    import seaborn as sns
    import warnings
    warnings.filterwarnings('ignore')
    import pickle


    spark=SparkSession.builder.master('local').getOrCreate()     #creating spark session
    pd.set_option('display.max_rows', None)
    pd.set_option('display.float_format', lambda x: '%.3f' % x)

    df=pd.read_csv("5krecords.csv")
    ####################
    #data Cleaning
    ####################
    df.rename(columns={'Order Date':'orderDate','Item Type':'itemtype','Total Profit':'total_profit'},inplace=True)
    df=df[['orderDate','itemtype','total_profit']] #extracting required column
    # print(df.head(12))

    df['orderDate']=pd.to_datetime(df['orderDate'],infer_datetime_format=True)
    # print(df.info())
    # print("Features : ",df.columns.tolist())
    # print("Missing Values :",df.isnull().any())
    # print("Unique Values : ",df.nunique())

    df['orderDate'] = df['orderDate'].map(lambda x: x.strftime('%Y-%m'))  #converting to year and month
    item_df=df.set_index('orderDate')
    # print(item_df)


    # sns.lineplot(x="orderDate",y='total_profit',data=item_df)
    # plt.show()
    # sns.lineplot(x="itemtype",y='total_profit',data=item_df)
    # plt.show()

    ###############
    # here we create spark datafram
    ##################

    sdf=spark.createDataFrame(df)
    # sdf.show()
    # print(sdf.count())  #print total number of records
    sdf.select(['itemtype']).groupBy('itemtype').agg({'itemtype':'count'})
    # sdf.select(['itemtype']).groupBy('itemtype').agg({'itemtype':'count'}).show()
    #works as group by for item type called a lazy evaluated frame as it dosnt show data but creates one
    sdf.createOrReplaceTempView('sales')
    # print(sdf.count())
    # sdf.show()

    # sql1='SELECT itemtype,orderDate ,sum(total_profit) FROM sales group by itemtype order by itemtype'
    sql1='select itemtype,orderDate as ds,sum(total_profit) as y from sales group by itemtype,ds order by itemtype,ds'
    # spark.sql(sql1).show()

    sdf.rdd.getNumPartitions()
    # itemtype_partitions=(spark.sql(sql).repartition(spark.sparkContext.defaultParallelism['itemtype'])).cache()
    itemtype_partitions=(spark.sql(sql1).repartition(spark.sparkContext.defaultParallelism,['itemtype'])).cache()
    # print(itemtype_partitions.explain())

    result_schema=StructType([
        StructField('ds',DateType()),
        StructField('itemtype',StringType()),
        StructField('y',DoubleType()),
        StructField('yhat',DoubleType()),
        StructField('yhat_upper',DoubleType()),
        StructField('yhat_lower',DoubleType())
    ])


    @pandas_udf( result_schema,PandasUDFType.GROUPED_MAP)
    def forcast_profit(itemtype_Pd):
        model=Prophet(interval_width=0.95,seasonality_mode='multiplicative')
        model.fit(itemtype_Pd)

        future_pd=model.make_future_dataframe(periods=period,freq='m')
        forcast_pd=model.predict(future_pd)
        model.plot(forcast_pd)
        model.plot_components(forcast_pd)
        f_pd=forcast_pd[['ds','yhat','yhat_upper','yhat_lower']].set_index('ds')
        st_pd=itemtype_Pd[['ds','itemtype','y']].set_index('ds')
        result_pd=f_pd.join(st_pd,how='left')
        result_pd.reset_index(level=0,inplace=True)
        result_pd['itemtype']=itemtype_Pd['itemtype'].iloc[0]
        return result_pd[['ds','itemtype','y','yhat','yhat_upper','yhat_lower']]


    results=(
        itemtype_partitions
        .groupBy('itemtype')
        .apply(forcast_profit)
        .withColumn('orderDate',current_date())
    )
    results.cache()

    print(results)  #prints address
    # results.show()
    print(results.toPandas())
    print("====")
    # pickle.dump(results, open('5k_predictions.pkl', 'wb+'))
    # pickle.dump(results,open())


    # print(results.explain())
    # # results.orderBy(desc("itemtype")).show()   #display last 20 rows
    # print(results.count())
    # print("file written")
    # print("---")
    # dbfile= open('5m_predictions.pkl','rb')
    # db = pickle.load(dbfile)
    # for keys in db:
    #     print
    # dbfile.close()

    # results_df = results.toPandas()
    # # results_df=results_df.history.copy().reset_index(drop=True)
    # cv_results =cross_validation(model=results_df, initial='730 days', period='180 days', horizon = pd.Timedelta('365 days'))
    # # cv_results=cross_validation(model=results, horizon = 365/12, units = "days", period = 362/12,initial = 20*12*(365/12))
    #
    # cv_results.head(5)
    # df_perf=performance_metrics(cv_results)
    # df_perf.head()

    # results.explain()
    # print("Error : ",mean_squared_error(results['y'],results['yhat']))
    # print("Accuracy : ",r2_score(results['y'],results['yhat']))
    results.coalesce(1)
    results.count()
    results.createOrReplaceTempView('forcasted')
    spark.sql("select itemtype,count(*) from forcasted group by itemtype").show()
    final_op=results.toPandas()
    print(final_op)
    final_op=final_op.set_index('ds')
    final_op.query('itemtype=="{}"'.format(category))[['y','yhat']].plot()
    plt.xlabel("{}".format(category))
    plt.ylabel("Predicted Profit")
    plt.title("monthwise profit for category({})".format(category))
    plt.savefig('static/images/{}.jpg'.format(category))
    # final_op.query('itemtype=="Baby Food"')[['y','yhat']].plot()
    # plt.xlabel("Baby Food")
    # plt.ylabel("Predicted Profit")
    # plt.title("monthwise profit for category(Baby Food)")
    # plt.show()


    return " "
# a=main(18)
# print(a)